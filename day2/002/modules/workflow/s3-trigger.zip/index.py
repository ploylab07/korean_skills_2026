import json
import os
from urllib.parse import unquote_plus

import boto3

sfn = boto3.client("stepfunctions")


def handler(event, context):
    state_machine_arn = os.environ["STATE_MACHINE_ARN"]
    started = 0
    for record in event.get("Records", []):
        key = unquote_plus(record["s3"]["object"]["key"])
        sfn.start_execution(
            stateMachineArn=state_machine_arn,
            input=json.dumps({"key": key}),
        )
        started += 1
    return {"statusCode": 200, "started": started}
