import base64
import difflib
import json
import os
from datetime import datetime, timezone, timedelta

import boto3

ssm = boto3.client("ssm")
logs = boto3.client("logs")

INSTANCE_ID = os.environ["INSTANCE_ID"]
PARAM_NAME = os.environ["PARAM_NAME"]
LOG_GROUP = os.environ["LOG_GROUP"]
SERVICE = os.environ.get("SERVICE_NAME", "gj2026-app")


def _run_shell(script: str) -> str:
    resp = ssm.send_command(
        InstanceIds=[INSTANCE_ID],
        DocumentName="AWS-RunShellScript",
        Parameters={"commands": [script]},
        TimeoutSeconds=120,
    )
    cmd_id = resp["Command"]["CommandId"]
    waiter = ssm.get_waiter("command_executed")
    waiter.wait(CommandId=cmd_id, InstanceId=INSTANCE_ID, WaiterConfig={"Delay": 2, "MaxAttempts": 60})
    out = ssm.get_command_invocation(CommandId=cmd_id, InstanceId=INSTANCE_ID)
    return out.get("StandardOutputContent", "")


def handler(event, context):
    health = _run_shell("curl -sf http://127.0.0.1:8080/health >/dev/null && echo OK || echo FAIL")
    if "OK" not in health:
        return {"status": "skip", "reason": "unhealthy"}

    current = _run_shell("sed 's/[[:space:]]*$//' /home/ec2-user/app.py")
    backup = ssm.get_parameter(Name=PARAM_NAME)["Parameter"]["Value"].rstrip()

    if current.rstrip() == backup.rstrip():
        return {"status": "noop"}

    ssm.put_parameter(Name=PARAM_NAME, Value=current.rstrip(), Type="String", Overwrite=True)
    return {"status": "updated"}
