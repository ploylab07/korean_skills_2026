import difflib
import json
import os
import time
from datetime import datetime, timezone, timedelta

import boto3

ssm = boto3.client("ssm")
logs = boto3.client("logs")

INSTANCE_ID = os.environ["INSTANCE_ID"]
PARAM_NAME = os.environ["PARAM_NAME"]
LOG_GROUP = os.environ["LOG_GROUP"]
SERVICE = os.environ.get("SERVICE_NAME", "gj2026-app")
KST = timezone(timedelta(hours=9))


def _run_shell(script: str) -> str:
    resp = ssm.send_command(
        InstanceIds=[INSTANCE_ID],
        DocumentName="AWS-RunShellScript",
        Parameters={"commands": [script]},
        TimeoutSeconds=120,
    )
    cmd_id = resp["Command"]["CommandId"]
    waiter = ssm.get_waiter("command_executed")
    waiter.wait(CommandId=cmd_id, InstanceId=INSTANCE_ID, WaiterConfig={"Delay": 2, "MaxAttempts": 60})
    out = ssm.get_command_invocation(CommandId=cmd_id, InstanceId=INSTANCE_ID)
    return out.get("StandardOutputContent", "")


def handler(event, context):
    # 채점 3-4: stop 후 60초 시점에 ALARM 상태 확인 가능하도록 복구 지연
    time.sleep(60)

    backup = ssm.get_parameter(Name=PARAM_NAME)["Parameter"]["Value"].rstrip()
    current = _run_shell("cat /home/ec2-user/app.py").rstrip()

    diff_lines = list(
        difflib.unified_diff(
            backup.splitlines(),
            current.splitlines(),
            fromfile="--- 백업 (정상 버전)",
            tofile="+++ 현재 파일 (장애 버전)",
            lineterm="",
        )
    )
    diff_text = "\n".join(diff_lines) if diff_lines else "(변경 없음)"

    restore_script = f"""#!/bin/bash
set -euo pipefail
cat > /home/ec2-user/app.py <<'EOFAPP'
{backup}
EOFAPP
chown ec2-user:ec2-user /home/ec2-user/app.py
systemctl restart {SERVICE}
"""
    _run_shell(restore_script)

    finished = datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S KST")
    message = "\n".join(
        [
            "[장애 감지] 복구 대상: app",
            "원인: app 프로세스 다운",
            "수정된 내용:",
            diff_text,
            "복구 내용: Parameter Store에서 파일 복원 + 서비스 재시작 완료",
            f"복구 완료 시각: {finished}",
        ]
    )

    try:
        logs.create_log_stream(logGroupName=LOG_GROUP, logStreamName="recovery")
    except logs.exceptions.ResourceAlreadyExistsException:
        pass

    logs.put_log_events(
        logGroupName=LOG_GROUP,
        logStreamName="recovery",
        logEvents=[{"timestamp": int(datetime.now().timestamp() * 1000), "message": message}],
    )
    return {"status": "recovered"}
